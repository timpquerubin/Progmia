<div class="avatar-image-preview col-sm-4 col-xs-4 col-md-3 col-lg-3">
	<canvas class="avatar-ctx" id="ctx-avatar-prev"></canvas>
</div> 