<div class="container">
	<div>
		<h1>Players' Activity</h1>
		<table class="table table-striped">
			<thead>
				<th><strong>Username</strong></th>
				<th><strong>Stage</strong></th>
				<th><strong>Level</strong></th>
				<th><strong>Points Scored</strong></th>
				<th><strong>Date Finished</strong></th>
			</thead>
			<tbody>
			<!--<?php foreach ($variable as $key => $value) { ?>-->
				<tr>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
				<!--<?php }?>-->
			</tbody>
		</table>
	</div>
</div>