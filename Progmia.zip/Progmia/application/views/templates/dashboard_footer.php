
	</body>
	<footer>
		<div class="footer container-fluid"><p style="float:right;padding:20px;">Copyright &copy; 2017 Progmia.</p></div>
	</footer>
</html>