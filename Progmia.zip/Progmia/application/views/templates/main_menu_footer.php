
	</body>
	<footer>
		<div class="container">
		</div>
	</footer>
    <script>var base_url = '<?php echo base_url() ?>';</script>
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/music-control.js"></script>

	<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.dataTables.min.js"></script>

	<script type="text/javascript" src="<?php echo base_url();?>assets/js/slick.min.js""></script>
	<script type="text/javascript" src="<?php echo base_url(); ?>assets/js/main-menu.js"></script>
</html>