	</body>
	<footer></footer>
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.steps.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/jquery.steps.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets/js/goal.js"></script>
</html>