
	<script type="text/javascript" src="<?php echo base_url();?>assets/js/bootstrap.min.js""></script>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/slick.css"/>
	<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>assets/css/slick-theme.css"/>

	  <script type="text/javascript">
	    $(document).ready(function(){
	      $('.single-item').slick();
	    });
	  </script>
	</body>
</html>